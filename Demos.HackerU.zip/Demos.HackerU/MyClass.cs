﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demos.HackerU
{
    public class MyClass
    {
        public static void MethodA()
        {
            Console.WriteLine("MethodA Invoked...");
        }
        public static void MethodB()
        {
            //Run Using Full Name: Namspace.Class.Method
            System.Console.WriteLine("MethodB Invoked...");
          
        }

    }
}
